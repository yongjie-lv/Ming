# this file is needed here to include configs when building project as a package
